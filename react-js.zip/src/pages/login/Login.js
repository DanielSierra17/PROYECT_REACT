import React from 'react';
import Formulario from '../../components/login/Login';
import "./Login.css";

function Login() {
    return (
            <Formulario />
    );
}

export default Login;