import React from 'react';
import E404 from '../../components/error_404/Error_404';
import "./Error_404.css";

function ER404() {
    return (
            <E404 />
    );
}

export default ER404;