import React from 'react';
import './Registrar.css';
import Form from '../../components/registrar/Registrar';

function Registrar() {
    return (
        <div>
            <Form/>
        </div>
    );
}

export default Registrar;