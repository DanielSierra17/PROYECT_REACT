import React from 'react';
import Tablero from '../../components/dashboard/Dashboard';
import './Dashboard.css';

function Dashboard() {
    return (
        <div className="contenedor">
            <Tablero />
        </div>
    );
}

export default Dashboard;