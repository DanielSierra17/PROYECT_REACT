import React from 'react';
import './Registrar.css';
import Form from '../../components/form/Form';

function Registrar() {
    return (
        <div>
            <Form/>
        </div>
    );
}

export default Registrar;