import React from 'react';
import './Dashboard.css';
import Dash from '../../components/dash/Dash';

function Dashboard() {
    return (
        <div>
            <Dash />
        </div>
    );
}

export default Dashboard;